rightsidebar_menu <- 'box(
  title = "rightSidebarMenu",
  width = NULL,
  rightSidebarMenu(
    rightSidebarMenuItem(
      icon = menuIcon(
        name = "birthday-cake",
        color = "red"
      ),
      info = menuInfo(
        title = "Langdon s Birthday",
        description = "Will be 23 on April 24th"
      )
    ),
    rightSidebarMenuItem(
      icon = menuIcon(
        name = "user",
        color = "yellow"
      ),
      info = menuInfo(
        title = "Frodo Updated His Profile",
        description = "New phone +1(800)555-1234"
      )
    )
  )
)'