social_buttons <- 'box(
  width = NULL,
  title = "Social Buttons",
  status = NULL,
  socialButton(
    url = "https://dropbox.com",
    type = "dropbox"
  ),
  socialButton(
    url = "https://github.com",
    type = "github"
  )
)'