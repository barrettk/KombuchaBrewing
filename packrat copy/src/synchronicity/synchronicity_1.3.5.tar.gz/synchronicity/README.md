+[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/synchronicity)](https://cran.r-project.org/package=synchronicity)
[![Build Status](https://travis-ci.org/kaneplusplus/synchronicity.png)](https://travis-ci.org/kaneplusplus/synchronicity)
[![Build status](https://ci.appveyor.com/api/projects/status/k7hjwydhaxpt9ndp/branch/master?svg=true)](https://ci.appveyor.com/project/kaneplusplus/synchronicity/branch/master)

