.onLoad <- function(libname, pkgname)
{
}

.onUnload <- function(libpath)
{
}
