# htmltools

<!-- badges: start -->

[![R build
status](https://github.com/rstudio/htmltools/workflows/R-CMD-check/badge.svg)](https://github.com/rstudio/htmltools)
[![CRAN
status](https://www.r-pkg.org/badges/version/htmltools)](https://CRAN.R-project.org/package=htmltools)
[![CRAN
Downloads](https://cranlogs.r-pkg.org/badges/grand-total/htmltools)](https://www.rpackages.io/package/htmltools)
[![monthly](https://cranlogs.r-pkg.org/badges/htmltools)](https://www.rpackages.io/package/htmltools)
[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-stable-brightgreen.svg)](https://www.tidyverse.org/lifecycle/#stable)
<!-- badges: end -->

Tools for HTML generation and output.
