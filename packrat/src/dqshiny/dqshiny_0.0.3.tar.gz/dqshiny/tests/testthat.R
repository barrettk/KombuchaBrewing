library(testthat)
library(dqshiny)

test_check('dqshiny')
