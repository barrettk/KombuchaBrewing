## WARNING: It is not safe to change the 'encoding'
## option during startup.
##
## The startup::startup() function will detect this
## and give an informative warning about this.
options(encoding = "C")
