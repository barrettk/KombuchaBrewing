## ERROR: Don't call update.packages() during startup
## because it is likely to cause an infinite recursive
## call to update.packages()
##
## startup::startup() will detect this and generate
## an informative error.
utils::update.packages()
