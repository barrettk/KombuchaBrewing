## Make browseURL() on files work in more cases (also via Rscript)
options(browser = function(...) R.utils::shell.exec2(...))



