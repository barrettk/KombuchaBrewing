message("*** sysinfo() ...")

print(startup::sysinfo())

message("*** sysinfo() ... DONE")
